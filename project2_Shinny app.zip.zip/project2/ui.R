#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#

library(shiny)
library(ggplot2)
library(shinydashboard)
library(DT)
library(htmltools)
library(shinydashboardPlus)
dashboardPage(
  skin = "blue",
  dashboardHeader(title = "Digital Modulation"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introduction", tabName = "introduction", icon = icon("info-circle")),
      menuItem("Binary Phase Shift Keying", tabName = "bpsk", icon = icon("signal")),
      menuItem("Basis functions in signal spaces", tabName = "basis_functions", icon = icon("wave-square")),
      tags$li(class = "sidebar-menu-item", style = "width: 200px;",
              menuItem("In-phase channel and quadrature channel", tabName = "iq_channels", icon = icon("project-diagram"))
      ),
      menuItem("BPSK transmission revisited", tabName = "bpsk_revisited", icon = icon("retweet")),
      menuItem("Quadrature Phase Shift Keying", tabName = "qpsk", icon = icon("square-full")),
      menuItem("Bit error rate", tabName = "bit_error_rate", icon = icon("chart-pie")),
      tags$li(class = "sidebar-menu-item", style = "width: 200px;",
              menuItem("Non-Orthogonal Multiple Access (NOMA)", tabName = "noma", icon = icon("network-wired"))
      ),
      menuItem("Monte Carlo Simulation", tabName = "monte_carlo", icon = icon("dice-d6"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "introduction",
              h2(HTML("<span style='color:red;'>Importance of Electromagnetic Waves</span>")),
              p(HTML("<span style='text-align:justify;'>Electromagnetic waves, including radio waves, are crucial because they propagate where sound and light cannot. For example: </span>")),
              p(HTML("<span style='text-align:justify;'>- **AM Radio**: With wavelengths in the hundreds of meters, AM radio waves can penetrate structures like walls without much interference. </span>")),
              p(HTML("<span style='text-align:justify;'>- **Visible Light**: In contrast, visible light has much shorter wavelengths and is easily reflected by objects like metal nails.</span>")),
              h2(HTML("<span style='color:red;'>Frequency Choices in Wireless Systems</span>")),
              p(HTML("<span style='text-align:justify;'>Wireless systems utilize frequencies from a few kilohertz to several hundred gigahertz. The choice of frequency depends on factors like material penetration and signal attenuation. For instance: </span>")),
              p(HTML("<span style='text-align:justify;'>- **Low Frequencies (AM Radio)**: Penetrate larger structures. </span>")),
              p(HTML("<span style='text-align:justify;'>- **High Frequencies (Wi-Fi, WiMAX) </span>")),
              p(HTML("<span style='text-align:justify;'>- **: Used for shorter ranges and higher data capacities. </span>")),
              h2(HTML("<span style='color:red;'>Modulation: Conveying Information Through Waves</span>")),
              p(HTML("<span style='text-align:justify;'>Modulation is the process of converting information, such as voice in this case, into a form that can be transmitted over a medium like phone lines or radio waves. This is necessary because the range of sound transmission through air is limited by the power our lungs can generate. By modulating the voice signal onto another medium like wire or radio waves, we can extend the distance over which the voice information can travel effectively. </span>")),
              p(HTML("<span style='text-align:justify;'>In simpler terms, modulation involves encoding information like voice into a format suitable for transmission over communication channels like wires or radio frequencies. This allows the voice data to travel much farther than it could through air alone, thanks to the modulation process that adapts the signal for the chosen transmission medium.. </span>")),
              p(HTML("<span style='text-align:justify;'>A single tone, like: </span>")),
              withMathJax(),  # Load MathJax library
              htmlOutput("latex_output"),  # Create a place to display LaTeX
              tags$head(
                HTML('<script type="text/javascript" async
             src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/latest.js?config=TeX-MML-AM_CHTML">
                     </script>')
              ),
              p(HTML("<span style='text-align:justify;'>, carries power but not information. Information is conveyed through changes in the signal, similar to Morse code. Modulation techniques vary a carrier's amplitude, frequency, or phase to encode data, allowing the transmission of information through electromagnetic waves. </span>")),
              p(HTML("<span style='text-align:justify;'>For simplicity just think of modulation as a way to map between the information bit 10101001 to a sine wave that can be propagted quickly in the air. </span>")),
              h2(HTML("<span style='color:red;'>Types of Modulation</span>")),
              p(HTML("<span style='text-align:justify;'>-   **Analog Modulation**: Varies signal properties continuously.</span>")),
              p(HTML("<span style='text-align:justify;'>-   **Digital Modulation**: Varies signal properties in discrete steps, though real-world transmission often makes these digital signals appear analog due to the inability to transmit perfect sharp edges.</span>")),
              p(HTML("<span style='text-align:justify;'>We only discuss two digital modulation scheme Binary Phase Shift Keying (BPSK) and Quadrature Phase Shift Keying (QPSK).</span>")),
              h2(HTML("<span style='color:red;'>Modulation process</span>")),
              p(HTML("<span style='text-align:justify;'>The modulation process, which involves mapping an information signal (like voice or data) onto a higher-frequency sinusoidal carrier wave for transmission over a medium (like wire, air, or space). A sinusoid, or sine wave, has three main parameters that can be varied: amplitude (height), phase (position), and frequency. Modulation techniques work by varying one or more of these parameters to represent the information being sent. Essentially, the voice or data signal gets encoded into the sinusoidal carrier wave by altering its amplitude, phase, or frequency patterns according to the information. This modulated carrier wave is then transmitted over the desired medium. At the receiving end, the process is reversed - the modulated carrier is demodulated to extract the original information signal from the variations in the sine wave parameters. The medium (wire, air, etc.) simply acts as the channel through which the modulated carrier wave travels. However, noise can corrupt the signal during transmission, which is an unfortunate reality.</span>")),
              p(HTML("<span style='text-align:justify;'>So in summary:</span>")),
              p(HTML("<span style='text-align:justify;'>1.  Information signal (voice, data) is mapped onto a sinusoidal carrier wave by modulating its parameters.</span>")),
              p(HTML("<span style='text-align:justify;'>2.  The modulated carrier is transmitted over a medium like wire or air.</span>")),
              p(HTML("<span style='text-align:justify;'>3.  At the receiver, demodulation extracts the original information from the modulated carrier.</span>")),
              p(HTML("<span style='text-align:justify;'>4.  Noise can disrupt or corrupt the signal during transmission over the medium.</span>")),
              
              tags$div(
                tags$p("The data set can be downloaded at:"),
                tags$a(href = "https://github.com/uvutna/COMP5120_Project-2", "https://github.com/uvutna/COMP5120_Project-2")
              ),
              tags$div(
                img(src = "5g-networking-for-business-banner.png", height = 400)
              ),
              tags$div(
                tags$p("Source at:"),
                tags$a(href = "https://www.arup.com/services/digital/5g-networking", "https://www.arup.com/services/digital/5g-networking")
              )
      ),
      tabItem(
        tabName = "bpsk",
        fluidPage(
          titlePanel("BPSK Bit Sequence modulation Visualization"),
          sidebarLayout(
            sidebarPanel(
              textInput("bit_sequence", "Enter a bit sequence (length 10):", value = "0010110010"),
              actionButton("plot_button", "Plot")
            ),
            mainPanel(
              plotOutput("wave_plot")
            )
          )
        ),
        p(HTML("<span style='text-align:justify;'>PSK is a modulation technique employed to transmit digital data by manipulating the phase of a carrier signal. A carrier signal is a basic sinusoidal waveform at a specific frequency. In PSK, the information is encoded by altering the starting point, or phase, of the carrier wave cycles. In PSK, distinct data bits are represented by various phase shifts of the carrier signal. For instance, a 180-degree phase shift might signify a binary 0, while a 0-degree phase shift might signify a binary 1. Other PSK variations use more than two phase shift combinations to encode multiple bits per symbol. To summarize, PSK conveys digital information by modulating the phase of a carrier signal rather than its amplitude or frequency. By shifting the phase of the carrier wave, PSK represents digital data as distinct signal states. This technique is extensively used in various communication systems, including Wi-Fi and Bluetooth.</span>")),
        withMathJax(),  # Load MathJax library
        htmlOutput("latex_output2")  # Create a place to display LaTeX
        
      ),
      tabItem(
        tabName = "basis_functions",
        tabsetPanel(
          tabPanel("Theory",
                   p(HTML("<span style='text-align:justify;'>The exploration of signal spaces offers a geometric perspective on how modulation operates in communication systems. Imagine describing a vector using coordinates (x, y), where this vector results from combining the standard basis vectors (1, 0) and (0, 1). These two functions, which are orthogonal, allow any vector in this space to be expressed as a linear combination of them—these are what we refer to as basis functions. Similarly, consider a set of basis functions that consist of unit width pulses spaced evenly apart in time. Each pulse operates independently, and using these pulses, you can construct any sequence of data, such as a series of square pulses. While each pulse serves as a basis function, this arrangement isn't the most efficient for generating complex signals because it requires many such pulses to create diverse signal forms..</span>")),
                   tags$div(
                     img(src = "basis.png", height = 400)
                   ),
                   p(HTML("<span style='text-align:justify;'>For an optimal set of basis functions, we aim to use the minimum number possible to represent a broad range of independent signals, both digital and analog. These basis functions must satisfy two main criteria:</span>")),
                   p(HTML("<span style='text-align:justify;'>1.  **Unit Energy**: Each basis function, such as the vectors (1, 0) and (0, 1) or specific unit pulses, should have unit energy, making them efficient for signal representation. This is quite easy since we can change the amplitude of a signal to meet this requirement.</span>")),
                   p(HTML("<span style='text-align:justify;'>2.  **Orthogonality**: Each basis function should be orthogonal to every other function within the set. Mathematically, this is expressed as:</span>")),
                   withMathJax(),  # Load MathJax library
                   htmlOutput("latex_output3"),  # Create a place to display LaTeX
                   p(HTML("<span style='text-align:justify;'>This property ensures that the basis functions do not interfere (or cancel) with each other, allowing for clear and distinct signal representation. A prime example of effective basis functions widely used in real communications systems is the sine and cosine waves, both of which have unit amplitude. These functions not only meet the criteria of orthogonality and unit energy but also form the fundamental basis for modulating signals in most communication systems..</span>"))
                   ),
          tabPanel("cosine and sine waves", 
                   plotOutput("bar_sine_Cosine")
                   
                   ),
          tabPanel("Orthogonality criterion", 
                   plotOutput("Product_of_Sine_and_Cosine")
                   
          )
        )
      ),
      
      tabItem(
        tabName = "iq_channels",
        fluidPage(
          titlePanel("In-phase channel and quadrature channel"),
          tabsetPanel(
            tabPanel("Theory",
                     p(HTML("<span style='text-align:justify;'>Consider a signal as a vector. There are two primary methods to represent this vector: rectangular and polar forms.</span>")),
                     p(HTML("<span style='text-align:justify;'>1.  **Rectangular Form**: In this representation, we use two perpendicular components termed the In-phase (I) and Quadrature (Q) components. Imagine these as x and y coordinates on a Cartesian plane. The component along the x-axis is called the In-phase component, denoted as S11, and the y-axis component is the Quadrature component, denoted as S12.</span>")),
                     p(HTML("<span style='text-align:justify;'>2.  **Polar Form**:</span>")),
                     withMathJax(),  # Load MathJax library
                     htmlOutput("latex_output4"),
                     p(HTML("<span style='text-align:justify;'>These methods provide a complete description of the signal. While rectangular form focuses on the coordinate-based projection, polar form emphasizes the signal vector's direction and length.</span>"))
            ),
            tabPanel("Bits versus symbols",
                     p(HTML("<span style='text-align:justify;'>In digital communication, the terms 'bit' and 'symbol' represent different concepts, although both can be depicted using wave functions like sinusoids. A 'bit' is the basic unit of digital information. In contrast, a 'symbol' represents a specific arrangement or pattern of bits and is the unit of data that the transmission medium actually conveys. Think of bits as small items or 'widgets,' and symbols as the 'boxes' that carry these widgets during transport. Just as you can pack one widget or multiple widgets into a box, a single symbol can represent one bit or multiple bits, depending on the modulation scheme used. This packing of multiple bits into a single symbol is essentially what modulation involves. In the context of analog communications, a symbol corresponds to a particular waveform shape, determined by a set convention, that encodes a set number of bits. To clarify further, the term 'baud rate' refers to the number of symbols transmitted per second. For example, if a communication system transmits at 200 bauds, it means it sends 200 symbols per second, regardless of how many bits each symbol represents. The frequency of these transmissions, such as a 1 Hz signal, doesn’t convey the actual rate of data transmission but serves as an illustrative measure of how often symbols are sent.</span>"))
            ),
            tabPanel("BPSK analogy",
                     p(HTML("<span style='text-align:justify;'>Imagine a ship at sea that needs to send a distress signal to an airplane overhead using a simple light-based communication system. The captain uses a bright light and two designated spots on either side of the ship's mast. When the light is placed on the right, it represents the binary '1', and when it's on the left, it represents '0'. This setup is based on the premise that observers (airplanes) understand the binary meaning of the light positions. This method of signaling uses a one-dimensional approach, where the captain only moves the light horizontally (left to right) to change the symbol or bit being communicated. The act of moving the light between these two positions can be compared to a type of digital modulation known as Binary Phase Shift Keying (BPSK). In BPSK, information (bits) is encoded in the phase of a carrier wave, not in the amplitude or frequency. Specifically, two phases of the carrier wave are used: one with zero degrees (representing one symbol, say 's1') and another with 180 degrees (representing the other symbol, say 's2'). This shift in phase directly corresponds to the light moving from one side to the other. In BPSK, typically, there's no vertical component (Y-axis) in the signal—it's all based on the X-axis changes. The vector representing the signal flips along the X-axis based on the bit value, with no change in the Y-axis because the sine of both 0° and 180° is zero, resulting in no Y-component.</span>")),
                     tags$div(
                       img(src = "constellation.png", height = 400)
                     )
                     
            )
            
           
            
          )
        )
      ),
      tabItem(
        tabName = "bpsk_revisited",
        fluidPage(
          titlePanel("BPSK transmission revisited"),
          tabsetPanel(
            tabPanel("Theory", 
                     withMathJax(),  # Load MathJax library
                     htmlOutput("bpsk_text_output")
            ),
            tabPanel("modulated signal", 
                     fluidPage(
                       titlePanel("BPSK Bit Sequence Modulation"),
                       mainPanel(
                         plotOutput("modulation_plot"),
                         withMathJax(),  # Load MathJax library for any LaTeX rendering
                         htmlOutput("text_output_bpsk_explain")  # Create a place to display the text# Create a place to display the plot
                       )
                     )
                     
                     
            )
          )
        )
      ),
      
      tabItem(
        tabName = "qpsk",
        fluidPage(
          titlePanel("Quadrature Phase Shift Keying"),
          tabsetPanel(
            tabPanel("Theory", 
                     withMathJax(),  # Load MathJax library for any LaTeX rendering
                     htmlOutput("text_output_qpsk")  # Create a place to display the text
            ),
            tabPanel("Mathematical Representation", 
                     fluidPage(
                       titlePanel("Mathematical Representation"),
                       withMathJax(),
                       mainPanel(
                           # Load MathJax library for LaTeX rendering
                         htmlOutput("text_output_mathatic_qpsk")  # Create a place to display the text
                       ),
                       tags$div(
                         img(src = "rotation.png", height = 400)
                       ),
                       withMathJax(),  # Load MathJax library for LaTeX rendering
                       mainPanel(
                         htmlOutput("text_output_qpsk2"),
                         p(HTML("<span style='text-align:justify;'>From the table above, the corresponding visualization is</span>"))# Create a place to display the text and table
                       ),
                      
                       tags$div(
                         img(src = "QPSK.png", height = 400)
                       )
                     )
            ),
            tabPanel("Modulated QPSK Signal Visualization", 
                     sidebarLayout(
                       sidebarPanel(
                         textInput("bit_sequence_mod", "Enter a bit sequence (length 10):", value = "0010110010"),
                         actionButton("plot_button_mod", "Plot")
                       ),
                       mainPanel(
                         plotOutput("modulated_plot_qpsk")
                       )
                     )
            )
          )
        )
      ),
      tabItem(
        tabName = "bit_error_rate",
        fluidPage(
          titlePanel("Bit error rate"),
          tabsetPanel(
            tabPanel("Digital Communication and Bit Error Rate", 
                     withMathJax(),  # Load MathJax library for LaTeX rendering
                     mainPanel(
                       htmlOutput("text_output_bit_error")  # Create a place to display the text
                     )
            ),
            tabPanel("Simulated and Theoretical BER", 
                     fluidPage(
                       titlePanel("Simulated and Theoretical BER with varing N"),
                       sidebarLayout(
                         sidebarPanel(
                           selectInput("N_value", "Choose N value:", 
                                       choices = c("100", "1000", "10000", "100000", "1000000"))
                         ),
                         mainPanel(
                           plotOutput("ber_plot")
                         )
                       )
                     )
                     
                     
            ),
            tabPanel("BER vs. Eb/N0 for Various Modulation Schemes", 
                     fluidPage(
                       titlePanel("BER vs. Eb/N0 for Various Modulation Schemes"),
                       htmlOutput("text_output_ber_expalain"),
                       mainPanel(
                         plotOutput("ber_plot_compare")
                       )
                     )
                     
                     
            )
            
          )
        )
      ),
      tabItem(
        tabName = "noma",
        fluidPage(
          titlePanel("Non-Orthogonal Multiple Access (NOMA)"),
          tabsetPanel(
            tabPanel("Introduction", 
                     withMathJax(),  # Load MathJax library
                     htmlOutput("text_output_noma_introduction")
            ),
            tabPanel("Example of Superposition Coding", 
                     withMathJax(),  # Load MathJax library
                     htmlOutput("text_output_noma_example"),
                     tags$div(
                       img(src = "fig1SIC.png", height = 400)
                     )
            ),
            tabPanel("Digital Modulation", 
                     withMathJax(),  # Load MathJax library
                     htmlOutput("text_output_noma_digtal_modulation"),
                     tags$div(
                       img(src = "fig2SIC.png", height = 400)
                     )
            ),
            tabPanel("Superposition Coding", 
                     mainPanel(
                       h3("Superposition Coding involves power domain multiplexing, essentially adding x1 and x2 after scaling them with different power levels."),
                       p("Assume a1 = 0.75 for User 1 and a2 = 0.25 for User 2, with the rule that a1 + a2 = 1."),
                       p("First, scale x1 and x2 with the square roots of a1 and a2 respectively:"),
                       tags$ul(
                         tags$li("√a1 = √0.75 = 0.866"),
                         tags$li("√a2 = √0.25 = 0.5")
                       ),
                       p("After scaling:"),
                       tags$ul(
                         tags$li("√a1 * x1 = 0.866 -0.866 0.866 -0.866"),
                         tags$li("√a2 * x2 = -0.5 0.5 0.5 -0.5")
                       )
                     ),
                     tags$div(
                       img(src = "fig3SIC.png", height = 400)
                     ),
                     p("Next, add the scaled signals together to form the superposition coded signal:"),
                     tags$ul(
                       tags$li("x = √a1 * x1 + √a2 * x2"),
                       tags$li("Resulting in x = 0.366 -0.366 1.366 -1.366")
                     ),
                     tags$div(
                       img(src = "fig4SIC.png", height = 400)
                     ),
                     p("The signal x is the superposition coded NOMA signal that is transmitted into the channel. This demonstrates how superposition coding is performed. In the next section, we will explore how to recover x1 and x2 from x using successive interference cancellation (SIC).")
                     
            ),
            tabPanel("Recap and Successive Interference Cancellation (SIC) in NOMA", 
                     fluidPage(
                       titlePanel("Recap and Successive Interference Cancellation (SIC)"),
                       mainPanel(
                         withMathJax(),  # Load MathJax library for any LaTeX rendering
                         htmlOutput("text_output_noma_recap"),
                         # Create a place to display the text# Create a place to display the plot
                         tags$div(
                           img(src = "fig4SIC.png", height = 400)
                         )
                         
                         
                       )
                     )
                     
                     
            ),
            tabPanel("Example", 
                     fluidPage(
                       titlePanel("Step-by-Step Example"),
                       mainPanel(
                         HTML("
        <p>Given <code>a1 = 0.75</code> and <code>a2 = 0.25</code>, <code>x1</code> is given more power than <code>x2</code>. Following Step 1, direct decoding of <code>x</code> yields <code>x1</code>.</p>

        <p><strong>Direct decoding</strong> involves BPSK demodulation, which uses a simple thresholding method. Set the threshold to zero: if the amplitude exceeds zero, decode as <code>1</code>; otherwise, decode as <code>0</code>.</p>

        <p>For <code>x = 0.366 -0.366 1.366 -1.366</code>:</p>
        <ul>
          <li>First and third bit exceed zero: decode as <code>1</code>.</li>
          <li>Second and fourth bit are below zero: decode as <code>0</code>.</li>
        </ul>

        <p>Thus, <code>x</code> is decoded to <code>1010</code>, which is <code>x1</code>.</p>
      "),
                         # Create a place to display the text# Create a place to display the plot
                         tags$div(
                           img(src = "Step-by-Step%20Example.png", height = 400)
                         ),
                         h2(HTML("<span style='color:red;'>SIC Steps</span>")),
                         tags$div(
                           HTML("
          <ol>
            <li><strong>Decode <code>x</code> to get <code>x1</code></strong>:
              <ul>
                <li>BPSK demodulation gives <code>1010</code> from <code>x</code>.</li>
              </ul>
            </li>
            <li><strong>Subtract <code>√a1x1</code> from <code>x</code></strong>:
              <ul>
                <li>Remember <code>x1 = 1010</code> was BPSK modulated to <code>1 -1 1 -1</code>.</li>
                <li>Subtract <code>√a1 * (1 -1 1 -1)</code> from <code>x</code>.</li>
              </ul>
            </li>
            <li><strong>Decode the remaining signal</strong>:
              <ul>
                <li>The resulting signal is similar to the scaled data of user 2.</li>
                <li>Apply BPSK demodulation to this signal to get <code>x2</code>.</li>
              </ul>
            </li>
          </ol>
          <p>For <code>√a1 = 0.866</code> and <code>x1 = 1 -1 1 -1</code>:</p>
          <ul>
            <li>Subtract <code>0.866 -0.866 0.866 -0.866</code> from <code>x</code>.</li>
            <li>Result: <code>x - √a1x1 = -0.5 0.5 0.5 -0.5</code>.</li>
          </ul>
          <p><img src='x2.png' alt='Image Title'></p>
          <p>Finally, demodulate this resulting signal:</p>
          <ul>
            <li>First and fourth bit decode as <code>0</code>.</li>
            <li>Second and third bit decode as <code>1</code>.</li>
          </ul>
          <p>Thus, the decoded sequence is <code>0110</code>, which is <code>x2</code>.</p>
          <p>This demonstrates that SIC can effectively separate <code>x1</code> and <code>x2</code> from the superposition coded signal <code>x</code>.</p>
        ")
                         )
                         
                       )
                     )
            )
          )
        )
      ),
      #----------------
      tabItem(
        tabName = "monte_carlo",
        fluidPage(
          titlePanel("Monte Carlo Simulation"),
          tabsetPanel(
            tabPanel("System Model",
                     HTML("
        <h2>Downlink Communication Scenario</h2>
        <p>In a typical downlink communication scenario, consider a base station
        serving multiple users. Each user's channel from the base station is
        denoted by <i>h<sub>i</sub></i>, where <i>i</i> represents the user index. The channels are
        numbered such that user 1, with <i>h<sub>1</sub></i>, is the farthest and thus has the
        weakest signal, progressing to user <i>N</i>, who is nearest to the base
        station and has the strongest signal.</p>
      ")
            ),
            tabPanel("Signal Model for NOMA",
                     HTML("
      <h2>Non-Orthogonal Multiple Access (NOMA)</h2>
      <p>Non-Orthogonal Multiple Access (NOMA) allows the transmission of multiple user data on the same frequency band by utilizing superposition coding. The base station sends out a combined signal:</p>
      <p>
        $$ x_{\\text{NOMA}} = \\sqrt{P} \\left( \\sqrt{\\alpha_1} x_1 + \\sqrt{\\alpha_2} x_2 + \\ldots + \\sqrt{\\alpha_N} x_N \\right) $$
      </p>
      <p>where $P$ is the total transmit power and $\\alpha_i$ are the power allocation coefficients. At each user's receiver, Successive Interference Cancellation (SIC) is used to decode the signals intended for them, starting from the strongest signal.</p>
    ")
            ),
            tabPanel("Signal Model for OMA",
                     HTML("
        <p>Orthogonal Multiple Access (OMA), such as Time Division Multiple Access (TDMA), assigns different time slots or frequency bands to each user, ensuring no overlap and hence no interference between the signals. For example, in TDMA:</p>
        <p>$$ x_{\\text{OMA}} = \\sqrt{P} x_i $$</p>
        <p>during the i-th time slot, where $i$ represents the user index.</p>
      ")
                     
            ),
            tabPanel("Monte Carlo Simulation",
                     fluidPage(
                       
                       # Application title
                       titlePanel("Capacity of NOMA vs OMA"),
                       
                       # Sidebar layout with a plot output
                       sidebarLayout(
                         sidebarPanel(
                           h4("Plot Parameters"),
                           sliderInput("pt_range", 
                                       "SNR range (dB):",
                                       min = -114, 
                                       max = -54, 
                                       value = c(-114, -54)),
                           actionButton("update_plot", "Update Plot")
                         ),
                         
                         # Show the plot
                         mainPanel(
                           plotOutput("capacityPlot")
                         )
                       )
                     )
                     
                     
            )
            
            
            
          )
        )
      )
      
      
    )
  )
)