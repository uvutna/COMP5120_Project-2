#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#

library(shiny)
library(readr)
library(dplyr)
library(ggplot2)
library(broom)
library(base64enc)
library(shinyjs)
library(plotly)
library(readr)
library(gridExtra)
# Function to generate square wave
generate_square_waveBPSK <- function(bit_sequence, bit_duration) {
  total_time <- nchar(bit_sequence) * bit_duration
  t <- seq(0, total_time, by = 0.01)
  square_wave <- numeric(length(t))
  
  for (i in 1:nchar(bit_sequence)) {
    bit_value <- as.numeric(substr(bit_sequence, i, i))
    start_index <- ((i - 1) * bit_duration / 0.01) + 1
    end_index <- i * bit_duration / 0.01
    square_wave[start_index:end_index] <- bit_value
  }
  
  return(list(t = t, square_wave = square_wave))
}

#----------
# Function to generate square wave
generate_square_wave <- function(bit_sequence, bit_duration) {
  total_time <- nchar(bit_sequence) * bit_duration
  
  # Time vector with 0.01 second resolution
  t <- seq(0, total_time, by = 0.01)
  
  # Initialize square wave vector
  square_wave <- numeric(length(t))
  
  # Generate square wave
  for (i in 1:nchar(bit_sequence)) {
    bit_value <- as.numeric(substr(bit_sequence, i, i))
    start_index <- ((i - 1) * bit_duration / 0.01) + 1
    end_index <- i * bit_duration / 0.01
    square_wave[start_index:end_index] <- bit_value
  }
  
  return(list(t = t, square_wave = square_wave))
}
#---------------------
# Helper functions
split_bit_sequenceQPSK <- function(bit_sequence) {
  substring_length <- 2
  num_substrings <- floor(nchar(bit_sequence) / substring_length)
  bit_substrings <- vector("list", num_substrings)
  for (i in seq_len(num_substrings)) {
    start_index <- (i - 1) * substring_length + 1
    bit_substrings[[i]] <- substring(bit_sequence, start_index, start_index + substring_length - 1)
  }
  return(bit_substrings)
}

generate_square_waveQPSK <- function(bit_sequence, bit_duration) {
  total_time <- nchar(bit_sequence) * bit_duration
  t <- seq(0, total_time, by = 0.01)
  square_wave <- numeric(length(t))
  for (i in seq_along(bit_sequence)) {
    bit_value <- as.numeric(substr(bit_sequence, i, i))
    start_index <- (i - 1) * (bit_duration / 0.01) + 1
    end_index <- i * (bit_duration / 0.01)
    square_wave[start_index:end_index] <- bit_value
  }
  return(list(wave = square_wave, time = t))
}
#---------------------

# Define server logic required to draw a histogram
function(input, output, session) {

    output$distPlot <- renderPlot({

        # generate bins based on input$bins from ui.R
        x    <- faithful[, 2]
        bins <- seq(min(x), max(x), length.out = input$bins + 1)

        # draw the histogram with the specified number of bins
        hist(x, breaks = bins, col = 'darkgray', border = 'white',
             xlab = 'Waiting time to next eruption (in mins)',
             main = 'Histogram of waiting times')

    })
    output$latex_output <- renderUI({
      HTML(paste0("<span style='text-align:justify;'>", "$$ \\cos \\left( {\\omega t} \\right) $$", "</span>"))
    })
    output$latex_output2 <- renderUI({
      withMathJax(HTML(
        "$$PSK\\left( t \\right) = \\left\\{ 
      \\begin{array}{ll}
      \\sin \\left( 2\\pi ft \\right) & \\text{for bit 1} \\\\
      \\sin \\left( 2\\pi ft + \\pi \\right) & \\text{for bit 0}
      \\end{array} \\right.$$"
      ))
    })
    
    output$latex_output3 <- renderUI({
      withMathJax(HTML(
        "$$\\int_{-\\infty}^{\\infty} \\phi_i(t) \\phi_j(t) \\, dt = 
      \\begin{cases} 
      1 & \\text{if } i = j \\\\
      0 & \\text{if } i \\neq j
      \\end{cases}$$"
      ))
    })
    
    observeEvent(input$plot_button, {
      req(nchar(input$bit_sequence) == 10) # Ensure the length is exactly 10
      output$wave_plot <- renderPlot({
        bit_sequence <- input$bit_sequence
        bit_duration <- 1
        f <- 2
        
        wave_data <- generate_square_waveBPSK(bit_sequence, bit_duration)
        t <- wave_data$t
        square_wave <- wave_data$square_wave
        
        y1 <- sin(2 * pi * f * t)
        y2 <- sin(2 * pi * f * t + pi)
        modulated_stream <- ifelse(square_wave == 1, y1, y2)
        
        plot_data <- data.frame(Time = t, SquareWave = square_wave, ModulatedStream = modulated_stream)
        annotations <- data.frame(
          Time = seq(bit_duration / 2, by = bit_duration, length.out = nchar(bit_sequence)),
          Label = unlist(strsplit(bit_sequence, ""))
        )
        vertical_lines <- data.frame(
          VLineTime = seq(0, max(t), by = bit_duration)
        )
        
        ggplot(data = plot_data, aes(x = Time)) +
          geom_line(aes(y = SquareWave, colour = "Information Bit"), size = 1.0) +
          geom_line(aes(y = ModulatedStream, colour = "Modulated Information Bit"), size = 0.8) +
          geom_text(data = annotations, aes(x = Time, y = 1.2, label = Label), vjust = -0.5, size = 5, colour = "black") +
          geom_vline(data = vertical_lines, aes(xintercept = VLineTime), linetype = "dashed", colour = "magenta", size = 0.8) +
          scale_color_manual(values = c("Information Bit" = "blue", "Modulated Information Bit" = "red")) +
          labs(x = "Time (s)", y = "Amplitude") +
          ggtitle("Bit Sequence to Wave (1 second Bit Duration)") +
          theme_minimal() +
          scale_y_continuous(limits = c(-1.5, 1.5)) +
          theme(legend.title = element_blank())
      })
    })
    
    #----------------------
    output$bar_sine_Cosine <- renderPlot({
      # Define the data for cosine and sine waves over two periods
      x_values <- seq(0, 4 * pi, length.out = 100)
      cosine_data <- data.frame(x = x_values, y = cos(x_values))
      sine_data <- data.frame(x = x_values, y = sin(x_values))
      
      # Plot the cosine wave
      p1 <- ggplot(cosine_data, aes(x, y)) +
        geom_line(color = "blue") +
        ggtitle("Cosine Wave") +
        theme_minimal()
      
      # Plot the sine wave
      p2 <- ggplot(sine_data, aes(x, y)) +
        geom_line(color = "red") +
        ggtitle("Sine Wave") +
        theme_minimal()
      
      # Combine the plots
      grid.arrange(p1, p2, ncol = 1)
    })
    
    output$Product_of_Sine_and_Cosine <- renderPlot({
      # Define the data for sine and cosine and their product over one period (0 to 2*pi)
      x_values <- seq(0, 2 * pi, length.out = 500)
      data <- data.frame(
        x = x_values,
        cosine = cos(x_values),
        sine = sin(x_values),
        product = cos(x_values) * sin(x_values)
      )
      
      # Add a column for fill based on the sign of the product
      data$fill_color <- ifelse(data$product >= 0, 'blue', 'red')
      
      # Plotting
      p <- ggplot(data, aes(x = x)) +
        geom_area(aes(y = product, fill = fill_color), alpha = 0.5) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        labs(title = "Product of Sine and Cosine Over One Period",
             x = "x",
             y = "cos(x) * sin(x)") +
        theme_minimal() +
        scale_fill_identity()  # Use the colors specified in the data frame
      
      print(p)
    })
    output$latex_output4 <- renderUI({
      withMathJax(HTML(
        "
      
      <p>The same signal can also be described by its magnitude and angle. The magnitude of the signal vector is calculated as 
      \\( S = \\sqrt{I^2 + Q^2} \\), where \\( I \\) and \\( Q \\) are the In-phase and Quadrature components respectively. The angle \\( \\theta \\) 
      of the vector, representing the phase of the signal, is determined by 
      \\( \\theta = \\tan^{-1} \\left( \\frac{Q}{I} \\right) \\).
      </p>
      "
      ))
    })
    
    output$bpsk_text_output <- renderUI({
      HTML(
        "Let us examine how to send the bit sequence <code>0010110010</code> using BPSK,
      where each bit corresponds to a specific phase of a carrier wave. In
      BPSK, we use two phases: one for bit '0' and another for bit '1'.
      Specifically, let’s denote a 0 degree phase shift as symbol s1 for bit
      '0' and a 180 degree phase shift as symbol s2 for bit '1'.
      <br><br>
      Following this scheme, the bit sequence <code>0010110010</code> translates into the
      symbol sequence:
      <ul>
        <li><code>0</code> becomes s1,</li>
        <li><code>0</code> becomes s1,</li>
        <li><code>1</code> becomes s2,</li>
        <li><code>0</code> becomes s1,</li>
        <li><code>1</code> becomes s2,</li>
        <li><code>1</code> becomes s2,</li>
        <li><code>0</code> becomes s1,</li>
        <li><code>0</code> becomes s1,</li>
        <li><code>1</code> becomes s2,</li>
        <li><code>0</code> becomes s1.</li>
      </ul>
      This results in the symbol sequence: s1 s1 s2 s1 s2 s2 s1 s1 s2 s1.
      <br><br>
      When this sequence is modulated onto a carrier wave, each transition
      from s1 to s2 or from s2 to s1 represents a 180-degree phase shift in
      the wave. If visualized, each s1 symbol would be seen as a phase of 0
      degrees, and each s2 as a phase of 180 degrees, with the shifts
      occurring at each bit change."
      )
    })
    
    output$modulation_plot <- renderPlot({
      # Define parameters
      f <- 2  # Frequency in Hz
      # User must enter exactly 10 bits
      bit_sequence <- '0010110010'
      bit_duration <- 1
      
      # Generate square wave
      wave_data <- generate_square_wave(bit_sequence, bit_duration)
      t <- wave_data$t
      square_wave <- wave_data$square_wave
      
      # Generate sine waves for bit 0 and bit 1
      y1 <- sin(2 * pi * f * t)
      y2 <- sin(2 * pi * f * t + pi)
      
      # Modulate square wave
      modulated_stream <- ifelse(square_wave == 1, y1, y2)
      
      # Prepare data for plotting
      plot_data <- data.frame(Time = t, SquareWave = square_wave, ModulatedStream = modulated_stream)
      
      # Calculate positions for annotations
      annotations <- data.frame(
        Time = seq(bit_duration / 2, by = bit_duration, length.out = nchar(bit_sequence)),
        Label = unlist(strsplit(bit_sequence, ""))
      )
      
      # Calculate positions for vertical lines
      vertical_lines <- data.frame(
        VLineTime = seq(0, max(t), by = bit_duration)
      )
      
      # Plot the square wave, modulated signal, annotations, and vertical lines
      ggplot(data = plot_data, aes(x = Time)) +
        geom_line(aes(y = SquareWave, colour = "Information Bit"), size = 1.0) +
        geom_line(aes(y = ModulatedStream, colour = "Modulated Information Bit"), size = 0.8) +
        geom_text(data = annotations, aes(x = Time, y = 1.2, label = Label), vjust = -0.5, size = 5, colour = "black") +
        geom_vline(data = vertical_lines, aes(xintercept = VLineTime), linetype = "dashed", colour = "magenta", size = 0.8) +
        scale_color_manual(values = c("Information Bit" = "blue", "Modulated Information Bit" = "red")) +
        labs(x = "Time (s)", y = "Amplitude") +
        ggtitle("Bit Sequence to Wave (1 second Bit Duration)") +
        theme_minimal() +
        scale_y_continuous(limits = c(-1.5, 1.5)) +
        theme(legend.title = element_blank())
    })
    output$text_output_bpsk_explain <- renderUI({
      HTML(
        "In practical terms, if you could view this signal on a network analyzer
      with a carrier frequency significantly higher than 1 Hz, you would
      notice the signal switching back and forth between these two phases.
      However, because the carrier frequency is high, the wave contains many
      cycles between each phase shift, making the transitions appear very
      rapid and frequent.<br><br>
      
      The term 'transition' in this context refers to these moments when the
      signal flips its phase. It’s crucial in BPSK since the integrity of data
      transmission relies on accurately detecting these phase changes despite
      potential distortions caused by amplifier non-linearities. Amplifiers
      can struggle with these rapid changes, which may introduce errors if not
      properly managed."
      )
    })
    
    output$text_output_qpsk <- renderUI({
      HTML(
        "Imagine a ship with a captain who has devised a sophisticated signaling
      method using four designated spots on the deck: East, West, North, and
      South. Each direction corresponds to a unique combination of two bits,
      thereby allowing the transmission of two bits with each signal flash.
      This setup, if operated in the same timeframe as a simpler single-bit
      system, would double the communication speed.
      <br><br>
      This technique introduces an additional dimension to the signaling
      because it utilizes two basis movements (East-West and North-South) to
      define four unique symbols (00, 01, 10, 11). This method is known as
      Quadrature Phase Shift Keying (QPSK), which is a two-dimensional
      modulation technique. In contrast to Binary Phase Shift Keying (BPSK)
      that transmits one bit per symbol along one dimension, QPSK sends two
      bits per symbol by incorporating two dimensions (sine and cosine waves)."
      )
    })
    output$text_output_mathatic_qpsk <- renderUI({
      withMathJax(HTML(
        "QPSK extends BPSK by employing M-ary signaling, where 'M' indicates the number of possible symbol states. 
      For QPSK, M equals 4, implying four possible phase shifts for the carrier wave. The expression for a QPSK signal can be described inline as:
      <br><br>
      \\( s_i(t) = A p(t) \\cos (2 \\pi f_c t + \\frac{2 \\pi i}{M}) \\)
      <br><br>
      Here, \\( p(t) \\) is a pulse shaping function, \\( f_c \\) is the carrier frequency, and \\( i \\) varies from 1 to M, denoting different phase shifts.
      <br><br>
      In digital phase modulation like QPSK, changes in the phase of the carrier wave encode different data bits. For QPSK, with M=4, each modulation angle 
      \\( \\theta_i \\) is calculated as:
      <br><br>
      \\( \\theta_i = \\frac{2 \\pi i}{M} \\)
      <br><br>
      These phase shifts enable the encoding of two bits per symbol, enhancing the data transmission efficiency compared to BPSK. This modulation is part of 
      what's known as rotation invariant, where the system's overall power and performance remain constant, irrespective of the constellation diagram's rotation."
      ))
    })
    
    output$text_output_qpsk2 <- renderUI({
      withMathJax(HTML(
        "As such, the general equation in the case of arbitrary $M$-PSK
      Modulation is
      \\( s_i(t) = \\sqrt{\\frac{2E_s}{T}} \\cos \\left(2\\pi f_c t + \\frac{2\\pi i}{M}\\right) \\).
      For example with QPSK then \\( i=0,1,2,3 \\) and \\( M=4 \\)
      <br><br>
      $$ 
      \\begin{array}{|c|c|c|}
      \\hline
      \\textbf{Symbol} & \\textbf{Bit Group} & s(t) \\\\
      \\hline
      s_1 & 00 & \\sqrt{\\frac{2E_s}{T}} \\cos \\left(2\\pi f_c t + \\frac{\\pi}{4}\\right) \\\\
      \\hline
      s_2 & 01 & \\sqrt{\\frac{2E_s}{T}} \\cos \\left(2\\pi f_c t + \\frac{3\\pi}{4}\\right) \\\\
      \\hline
      s_3 & 10 & \\sqrt{\\frac{2E_s}{T}} \\cos \\left(2\\pi f_c t + \\frac{5\\pi}{4}\\right) \\\\
      \\hline
      s_4 & 11 & \\sqrt{\\frac{2E_s}{T}} \\cos \\left(2\\pi f_c t + \\frac{7\\pi}{4}\\right) \\\\
      \\hline
      \\end{array}
      $$"
      ))
    })
    
    observeEvent(input$plot_button_mod, {
      req(nchar(input$bit_sequence_mod) == 10) # Ensure the length is exactly 10
      output$modulated_plot_qpsk <- renderPlot({
        bit_sequence <- input$bit_sequence_mod
        bit_duration <- 1
        fc <- 1
        substrings <- split_bit_sequenceQPSK(bit_sequence)
        square_wave_data <- generate_square_waveQPSK(bit_sequence, bit_duration)
        t <- square_wave_data$time
        square_wave <- square_wave_data$wave
        
        # Placeholder for modulated signal data
        temp <- numeric(0)
        symbol_duration <- 2 * bit_duration
        t_symbol <- seq(0, symbol_duration, by = 0.01)
        
        # Generate modulated signals
        for (substring in substrings) {
          if (substring == "00") {
            s1 <- cos(2 * pi * fc * t_symbol + pi / 4)
            temp <- c(temp, s1)
          } else if (substring == "01") {
            s2 <- cos(2 * pi * fc * t_symbol + 3 * pi / 4)
            temp <- c(temp, s2)
          } else if (substring == "11") {
            s3 <- cos(2 * pi * fc * t_symbol + 5 * pi / 4)
            temp <- c(temp, s3)
          } else if (substring == "10") {
            s4 <- cos(2 * pi * fc * t_symbol + 7 * pi / 4)
            temp <- c(temp, s4)
          }
        }
        
        # Plotting
        plot(seq_along(temp), temp, type = "l", col = "blue", xlab = "Time Sample", ylab = "Amplitude", xlim = c(0, length(temp)), ylim = c(-1.5, 1.5), main = "Modulated Signal")
        
        # Annotating each substring and adding dashed vertical lines
        time_increment <- length(t_symbol)
        for (i in seq_along(substrings)) {
          midpoint <- (i - 0.5) * time_increment
          text(midpoint, 1.4, substrings[[i]], col = "red")
          if (i < length(substrings)) {
            abline(v = i * time_increment, lty = "dashed", col = "magenta")
          }
        }
        abline(v = length(substrings) * time_increment, lty = "dashed", col = "magenta")
      })
    })
    
    #------------
    output$text_output_bit_error <- renderUI({
      withMathJax(HTML(
        "In radio communication, data is transmitted over airwaves, which are
      prone to random noise, primarily from the hardware and the environment.
      This noise usually follows a Gaussian distribution and causes random
      errors in the received data. Occasionally, many errors might occur all
      at once, especially due to problems like signal fading or movement
      (Doppler effects).
      <br><br>
      However, errors are technically not a part of the signal until it's
      interpreted by a receiver. In digital communication, the original signal
      is analog, and 'bit errors' only exist once the digital receiver tries
      to interpret (decode) the signal. The type of modulation (how data is
      encoded into the signal) greatly influences how likely errors are
      because it determines how closely packed data symbols are in the signal.
      The closer they are, the harder it is for the receiver to distinguish
      them without errors. This sensitivity of the receiver in making correct
      decisions is crucial in determining the quality of the communication
      link. If we sent `0000` and receive `1000` this implies that our bit
      error rate is 25\\%.
      <br><br>
      For BPSK, the theoretical BER is
      \\( Q\\left( \\sqrt{ \\frac{2E_b}{N_0} } \\right) \\) where \\( Q\\left( x \\right) = \\frac{1}{\\sqrt{2\\pi}} \\int_{u=x}^{\\infty} \\exp \\left( -\\frac{u^2}{2} \\right) du \\) 
      and \\( \\frac{E_b}{N_0} \\) is the energy per bit to noise power spectral density ratio. Interestingly, this formula can be validated through the
      use of Monte-Carlo simulation."
      ))
    })
    
    output$ber_plot <- renderPlot({
      # Generate the filename based on the selected N value
      filename <- paste0("BER_data_N", input$N_value, ".csv")
      
      # Read the CSV file
      data <- read.csv(filename)
      
      # Create the plot
      ggplot(data, aes(x = EbN0_dB)) +
        geom_point(aes(y = Simulated_BER, color = "Simulated BER"), shape = 1, size = 4) +  # Set color inside aes() for legend
        geom_line(aes(y = Theoretical_BER, color = "Theoretical BER")) +  # Set color inside aes() for legend
        scale_y_log10() +
        xlab("EbN0_dB") +
        ylab("BER") +
        ggtitle(paste("Simulated and Theoretical BER N =", input$N_value)) +
        theme_bw() +  # Base theme with grid
        theme(panel.grid.major = element_line(color = "grey", size = 0.5),  # Customize major grid lines
              panel.grid.minor = element_line(color = "lightgrey", size = 0.25),  # Customize minor grid lines
              legend.position = "bottom",  # Adjust legend position
              legend.text = element_text(size = 12),  # Increase legend text size
              legend.title = element_text(size = 14)) +  # Increase legend title size
        scale_color_manual(name = "Legend", values = c("Simulated BER" = "blue", "Theoretical BER" = "red")) +
        guides(color = guide_legend(override.aes = list(shape = c(1, NA))))  # Ensure correct shapes in legend
    })
    
    output$text_output_ber_expalain <- renderUI({
      HTML(
        "The same goes for other modulation schemes, note that BPSK and QPSK have
      the same BER but the spectral efficiency of QPSK is double that of
      BPSK. This implies that we could send more data reliably without
      sacrificing more energy."
      )
    })
    
    output$ber_plot_compare <- renderPlot({
      # Read the data
      data <- read_csv("BER_theoretical_data.csv")
      
      # Create the plot with a logarithmic y-axis
      ggplot(data, aes(x = EbN0_dB)) +
        geom_line(aes(y = BPSK, color = "BPSK"), linetype = "dashed", size = 2.2) +
        geom_point(aes(y = BPSK, color = "BPSK"), shape = 18, size = 3) + # Add points for BPSK
        geom_line(aes(y = QPSK, color = "QPSK"), linetype = "solid", size = 1.0) +
        geom_point(aes(y = QPSK, color = "QPSK"), shape = 17, size = 2) + # Add points for QPSK
        geom_line(aes(y = `8QAM`, color = "8QAM")) +
        geom_line(aes(y = `16QAM`, color = "16QAM")) +
        geom_line(aes(y = `32QAM`, color = "32QAM")) +
        labs(title = "BER vs. Eb/N0 for Various Modulation Schemes",
             x = "Eb/N0 (dB)",
             y = "Bit Error Rate (BER)",
             color = "Modulation Scheme") +
        scale_y_log10() +  # Apply logarithmic scale to y-axis
        theme_minimal() + 
        theme(
          legend.position = "bottom",  # Adjust legend position
          legend.text = element_text(size = 14),  # Increase legend text size
          legend.title = element_text(size = 16)  # Increase legend title size
        ) +
        scale_color_manual(name = "modulation scheme", values = c("BPSK" = "blue", "QPSK" = "red", "8QAM" = "green", "16QAM" = "purple", "32QAM" = "orange")) +
        guides(color = guide_legend(override.aes = list(shape = c(18, 17, NA, NA, NA))))  # Ensure correct shapes in legend
    })
    
    output$text_output_noma_introduction <- renderUI({
      HTML(
        "Non-Orthogonal Multiple Access (NOMA) is a potential multiple access
      scheme for 5G networks. One intriguing aspect of NOMA is its ability to
      allow multiple users to transmit and receive simultaneously on the same
      frequency. This is made possible by two key operations: superposition
      coding at the transmitter side and successive interference cancellation
      (SIC) at the receiver side. In this section, we will focus on
      superposition coding."
      )
    })
    
    output$text_output_noma_example <- renderUI({
      HTML(
        "Let's consider two users, User 1 and User 2, communicating
      simultaneously using the same frequency. Let `x1` represent User 1's
      data and `x2` represent User 2's data. For simplicity, assume each user
      has 4 bits of data to send, denoted as follows:
      <br><br>
      - `x1 = 1010`<br>
      - `x2 = 0110`"
      )
    })
    
    output$text_output_noma_digtal_modulation <- renderUI({
      HTML(
        "Before transmission, `x1` and `x2` must undergo digital modulation.<br>
      Using Binary Phase Shift Keying (BPSK) for simplicity:<br>
      - BPSK maps `0` to `-1` and `1` to `+1`.<br>
      - After BPSK modulation:<br>
      - `x1` becomes `+1 -1 +1 -1`<br>
      - `x2` becomes `-1 +1 +1 -1`"
      )
    })
    
    output$text_output_noma_recap <- renderUI({
      HTML("
      <div style='font-size:16px;'>
        <p>Previously, we discussed two users with data <code>x1</code> and <code>x2</code>. We performed BPSK modulation on both <code>x1</code> and <code>x2</code> and then combined them using superposition coding to get the signal <code>x = √a1x1 + √a2x2</code>, where <code>a1</code> and <code>a2</code> are the power weights assigned to <code>x1</code> and <code>x2</code> respectively, such that <code>a1 + a2 = 1</code>. We used <code>x1 = 1010</code> and <code>x2 = 0110</code> as examples. After BPSK modulation and choosing <code>a1 = 0.75</code> and <code>a2 = 0.25</code>, we obtained the superposition coded signal <code>x</code>.</p>
        <p>Superposition Coding involves power domain multiplexing, essentially adding <code>x1</code> and <code>x2</code> after scaling them with different power levels.</p>
        <p>Assume <code>a1 = 0.75</code> for User 1 and <code>a2 = 0.25</code> for User 2, with the rule that <code>a1 + a2 = 1</code>.</p>
        <p>First, scale <code>x1</code> and <code>x2</code> with the square roots of <code>a1</code> and <code>a2</code> respectively:</p>
        <ul>
          <li>√a1 = √0.75 = 0.866</li>
          <li>√a2 = √0.25 = 0.5</li>
        </ul>
        <p>After scaling:</p>
        <ul>
          <li>√a1 * x1 = 0.866 -0.866 0.866 -0.866</li>
          <li>√a2 * x2 = -0.5 0.5 0.5 -0.5</li>
        </ul>
        <p>Next, add the scaled signals together to form the superposition coded signal:</p>
        <ul>
          <li>x = √a1 * x1 + √a2 * x2</li>
          <li>Resulting in x = 0.366 -0.366 1.366 -1.366</li>
        </ul>
        <p>The signal <code>x</code> is the superposition coded NOMA signal that is transmitted into the channel. This demonstrates how superposition coding is performed. In the next section, we will explore how to recover <code>x1</code> and <code>x2</code> from <code>x</code> using successive interference cancellation (SIC).</p>
        <p>Before decoding, let’s understand the SIC algorithm. SIC is an iterative process where data is decoded in the order of decreasing power levels. The data of the user with the highest power is decoded first, followed by the data of the next highest power user, and so on. For our two-user NOMA system, the SIC steps are as follows:</p>
        <ol>
          <li><strong>Directly decode <code>x</code> to obtain the high-power signal.</strong>
            <ul>
              <li>If <code>x1</code> has more weight (i.e., <code>a1 > a2</code>), direct decoding of <code>x</code> gives <code>x1</code>.</li>
            </ul>
          </li>
          <li><strong>Subtract the decoded high-power signal from <code>x</code>.</strong>
            <ul>
              <li>Multiply the decoded <code>x1</code> by its corresponding weight and subtract it from <code>x</code>: <code>x - √a1x1</code>.</li>
            </ul>
          </li>
          <li><strong>Decode the remaining signal to get the low-power signal.</strong>
            <ul>
              <li>Decode <code>x - √a1x1</code> to obtain <code>x2</code>.</li>
            </ul>
          </li>
        </ol>
      </div>
    ")
    })
    
    #--------
    # Reactive expression to generate the plot based on input
    plot_data <- reactive({
      input$update_plot
      
      isolate({
        # Clear workspace
        rm(list = ls())
        
        # SNR range
        Pt <- seq(input$pt_range[1], input$pt_range[2], by = 1) # in dB
        pt <- 10^(Pt/10) # in linear scale
        
        N <- 10000
        
        d1 <- 5; d2 <- 3; d3 <- 2 # Distance of users
        eta <- 4 # Path loss exponent
        
        # Rayleigh fading coefficients of both users
        h1 <- (sqrt(d1^-eta)) * (complex(real = rnorm(N), imaginary = rnorm(N)) / sqrt(2))
        h2 <- (sqrt(d2^-eta)) * (complex(real = rnorm(N), imaginary = rnorm(N)) / sqrt(2))
        h3 <- (sqrt(d3^-eta)) * (complex(real = rnorm(N), imaginary = rnorm(N)) / sqrt(2))
        
        # Channel gains
        g1 <- Mod(h1)^2
        g2 <- Mod(h2)^2
        g3 <- Mod(h3)^2
        
        BW <- 10^9
        No <- -174 + 10*log10(BW)
        no <- (10^-3)*10^(No/10)
        
        # Power allocation coefficients
        a1 <- 0.75; a2 <- 0.1825; a3 <- 1 - (a1 + a2)
        
        C_noma_sum <- rep(0, length(pt))
        C_oma_sum <- rep(0, length(pt))
        
        for (u in 1:length(pt)) {
          
          # NOMA capacity calculation
          C_noma_1 <- log2(1 + pt[u]*a1*g1 / (pt[u]*a2*g1 + pt[u]*a3*g1 + no))
          C_noma_2 <- log2(1 + pt[u]*a2*g2 / (pt[u]*a3*g2 + no))
          C_noma_3 <- log2(1 + pt[u]*a3*g3 / no)
          C_noma_sum[u] <- mean(C_noma_1 + C_noma_2 + C_noma_3) # Sum capacity of NOMA
          
          # OMA capacity calculation
          C_oma_1 <- (1/3)*log2(1 + pt[u]*g1/no) # User 1
          C_oma_2 <- (1/3)*log2(1 + pt[u]*g2/no) # User 2
          C_oma_3 <- (1/3)*log2(1 + pt[u]*g3/no) # User 3
          C_oma_sum[u] <- mean(C_oma_1 + C_oma_2 + C_oma_3) # Sum capacity of OMA
          
        }
        
        SNR <- Pt - No
        
        # Data frame for ggplot
        data <- data.frame(SNR, NOMA = C_noma_sum, OMA = C_oma_sum)
        data
      })
    })
    
    output$capacityPlot <- renderPlot({
      data <- plot_data()
      ggplot(data, aes(x = SNR)) +
        geom_line(aes(y = NOMA, colour = "NOMA"), size = 1.2) +
        geom_line(aes(y = OMA, colour = "OMA"), size = 1.2) +
        labs(x = "SNR (dB)", y = "Achievable rate (bps/Hz)", title = "Capacity of NOMA vs OMA") +
        scale_color_manual(values = c("NOMA" = "blue", "OMA" = "red")) +
        theme_minimal() +
        theme(legend.title = element_blank(),
              plot.title = element_text(hjust = 0.5, size = 16),
              axis.text = element_text(size = 12),
              axis.title = element_text(size = 14),
              legend.text = element_text(size = 12)) +
        theme(panel.grid.major = element_line(colour = "gray", linetype = "dashed"),
              panel.grid.minor = element_blank())
    })

}
